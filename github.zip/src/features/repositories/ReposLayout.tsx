import RepositoriesList from "./components/RepositoriesList";

export default function ReposLayout() {
  return (
    <div className="mx-auto w-full">
      <RepositoriesList />
    </div>
  );
}
