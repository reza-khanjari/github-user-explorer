import UserPageLayout from "@features/user/components/UserPageLayout";

function UserPage() {
  return <UserPageLayout />;
}

export default UserPage;
