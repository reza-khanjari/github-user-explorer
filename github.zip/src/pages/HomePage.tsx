import HomePageLayout from "@features/home/HomePageLayout";

function HomePage() {
  return (
    <>
      <HomePageLayout />
    </>
  );
}

export default HomePage;
