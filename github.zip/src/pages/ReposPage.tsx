import ReposLayout from "@features/repositories/ReposLayout";

function ReposPage() {
  return <ReposLayout />;
}

export default ReposPage;
